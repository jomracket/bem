void wd1770_reset();
uint8_t wd1770_read(uint16_t addr);
void wd1770_write(uint16_t addr, uint8_t val);

