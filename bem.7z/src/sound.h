extern int sound_internal, sound_beebsid, sound_dac, sound_ddnoise, sound_tape;
extern int sound_filter;

void sound_init();
void sound_poll();
