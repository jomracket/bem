extern HINSTANCE hinstance;
extern HWND ghwnd;

