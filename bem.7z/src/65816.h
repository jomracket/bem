void w65816_init();
void w65816_reset();
void w65816_exec();
void w65816_close();
