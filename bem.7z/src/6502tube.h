void tube_6502_init_cpu();
void tube_6502_reset();
void tube_6502_exec();
void tube_6502_close();
void tube_6502_mapoutrom();
