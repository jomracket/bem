void z80_init();
void z80_reset();
void z80_exec();
void z80_close();
