void gui_enter();
